﻿<#PSScriptInfo
    .VERSION 1.0.0.0
    .GUID 93c08942-7ae4-4baa-b901-8ecf19e22b51
    .FILENAME Add-Shortcut.ps1
    .AUTHOR Hannes Palmquist
    .AUTHOREMAIL hannes.palmquist@outlook.com
    .CREATEDDATE 2020-09-29
    .COMPANYNAME Personal
    .COPYRIGHT (c) 2020, Hannes Palmquist, All Rights Reserved
#>
function Add-Shortcut {
    <#
    .DESCRIPTION
        Adds a windows shortcut
    .PARAMETER Target
        Sets the target for the shortcut
    .PARAMETER ShortcutDirectory
        Sets the directory where the lnk file should be created.
    .PARAMETER Name
        Sets the name of the lnk file.
    .EXAMPLE
        Add-Shortcut -Name 'Notepad' -Directory C:\Temp -Target C:\Windows\System32\notepad.exe
        
        Creates the shortcut for notepad
    #>

    [CmdletBinding()] # Enabled advanced function support
    param(
        [Parameter(Mandatory)]
        [string]
        $Target,

        [Parameter(Mandatory)]
        [string]
        $ShortcutDirectory,

        [Parameter(Mandatory)]
        [string]
        $Name 
    )

    BEGIN {
        if (-not (Test-Path $Target)) {
            throw 'Target does not exists...'
        }
        if (-not (Test-Path $ShortcutDirectory -PathType Container)) {
            throw 'Unable to located directory where the link should be created'
        }
    }

    PROCESS {
        try {
            $WScriptShell = New-Object -ComObject WScript.Shell
            $LnkPath = Join-Path -Path $ShortcutDirectory -ChildPath ('{0}.lnk' -f $Name)
            $Shortcut = $WScriptShell.CreateShortcut($LnkPath)
            $Shortcut.TargetPath = $Target
            $Shortcut.Save()
        } catch {
            throw $_
        }
    }
}
#endregion


