---
external help file: PS.Tools.WinUtility-help.xml
Module Name: PS.Tools.WinUtility
online version:
schema: 2.0.0
---

# Add-Shortcut

## SYNOPSIS

## SYNTAX

```
Add-Shortcut [-Target] <String> [-ShortcutDirectory] <String> [-Name] <String> [<CommonParameters>]
```

## DESCRIPTION
Adds a windows shortcut

## EXAMPLES

### EXAMPLE 1
```
Add-Shortcut -Name 'Notepad' -Directory C:\Temp -Target C:\Windows\System32\notepad.exe
```

Creates the shortcut for notepad

## PARAMETERS

### -Target
Sets the target for the shortcut

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ShortcutDirectory
Sets the directory where the lnk file should be created.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Name
Sets the name of the lnk file.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
