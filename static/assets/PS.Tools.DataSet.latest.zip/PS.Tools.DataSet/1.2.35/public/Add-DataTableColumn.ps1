﻿<#PSScriptInfo
    .VERSION 1.0.0.0
    .GUID 6197517b-5bf1-4bf4-b978-09993773da76
    .FILENAME Add-DataTableColumn.ps1
    .AUTHOR Hannes Palmquist
    .AUTHOREMAIL hannes.palmquist@outlook.com
    .CREATEDDATE 2020-10-13
    .COMPANYNAME Personal
    .COPYRIGHT (c) 2020, Hannes Palmquist, All Rights Reserved
#>
function Add-DataTableColumn {
    <#
    .DESCRIPTION
        Add columns to data tables. Columns can be added before or after rows have been added.

        The command operates in two modes, single column or multiple columns mode.

        Multiple mode
        In multiple mode it is possible to provide a string array 
        of column names. This is a fast and simple way to quickly 
        populate a table with empty columns.

        Single mode
        In single mode each call adds a single column to the table.
        The difference is that when single mode is used it is 
        possible to add caption, defaultvalue and expressions.

    .PARAMETER DataTable
        Defined the DataTable that columns should be added to
    .PARAMETER Names
        Defines the names of the columns. This is used to reference the column in the datatable.
    .PARAMETER Caption
        Sets the caption of the column. This is used when creating table views.
    .PARAMETER DefaultValue
        Sets the default value of a column. When set the cell of each row will get initialized with this default value.
    .PARAMETER Expression
        Sets a expression to calculate the cell value.

        For more information about expression variables and syntax see microsoft docs
        https://docs.microsoft.com/en-us/dotnet/api/system.data.datacolumn.expression?view=net-5.0
    
    .PARAMETER AllowDBNull
        Defaults to true, if set to false column will not allow null values
    
    .EXAMPLE
        Add-DataTableColumn -DataTable $DataTable -Names 'Firstname','Lastname','Address','Email'
        
        This example demostrates the use of multiple mode to create four columns in the DataTable object.

    .EXAMPLE
        Add-DataTableColumn -DataTable $DataTable -Names 'PreferredColor' -Caption 'Preferred color' -DefaultValue 'Blue'

        This example demostrates the use of single mode to create one column with a caption and a default value.
    
    .EXAMPLE 
        Add-DataTableColumn -DataTable $DataTable -Names 'Fee' -Expression '[Price] * [Amount]'

        This example demostrates the use of single mode to create one column with an expression
    #>

    [CmdletBinding(DefaultParameterSetName='Multiple')] # Enabled advanced function support
    param(
        [Parameter(Mandatory)]
        [System.Data.DataTable]
        $DataTable,

        [Parameter(Mandatory, ParameterSetName = 'Single')]
        [Parameter(Mandatory, ParameterSetName = 'Multiple')]
        [string[]]
        $Names,

        [Parameter(ParameterSetName = 'Single')]
        [string]
        $Caption,

        [Parameter(ParameterSetName = 'Single')]
        [string]
        $DefaultValue = '',

        [Parameter(ParameterSetName = 'Single')]
        [string]
        $Expression,

        [Parameter(ParameterSetName = 'Single')]
        [boolean]
        $AllowDBNull = $true
    )

    PROCESS {
        switch ($PSCmdlet.ParameterSetName) {
            'Single' {
                $DataColumn = New-Object System.Data.DataColumn -ArgumentList @($Names)[0]
                $DataColumn.Caption = $Caption
                $DataColumn.DefaultValue = $DefaultValue
                $DataColumn.DataType = [Object]
                if ($Expression) {
                    $DataColumn.Expression = $Expression
                }
                $DataColumn.AllowDBNull = $AllowDBNull

                [void]$DataTable.Columns.Add($DataColumn)
            }
            'Multiple' {
                foreach ($Name in $Names) {
                    $DataColumn = New-Object System.Data.DataColumn -ArgumentList $Name
                    $DataColumn.DataType = [Object]
                    [void]$DataTable.Columns.Add($DataColumn)
                }
            }
        }
    }
}
#endregion



# SIG # Begin signature block
# MIIUvwYJKoZIhvcNAQcCoIIUsDCCFKwCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUxAlf2OqgmAihvXyTWygB1Cdp
# hSSgghBHMIIDBDCCAeygAwIBAgIQXaH43Bl75ZhMB4kpXyZ2qjANBgkqhkiG9w0B
# AQUFADAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QwHhcNMjAxMDIyMDczMDU3
# WhcNMjUxMDIyMDc0MDU3WjAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QwggEi
# MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQClDvznsRz3hBOHS8rZ5ZlNB/ac
# GrKUQyoH0Pk6JONmIBeQPLwurne3ulSwb+6cbwwgp87eSnGoq4YbAFfqTbwytKLn
# YmIoHGiCrwxZb5YU6ijOrW6Sywa+H+/uKsZqJfXFRn1vGnC5tZwa5rSngLaow1qV
# tvyRQGRGNpI02hUwtChneJJmwk2B8dtY1ECH6Ob9LFlWETcETy5T5RKSS1sRWATk
# K9EQsZ65AHbGKGkpDv8y/+g7hg3KKU+m8f3ahMscMB5tvyPr3tmPsMFpFW3kCfz0
# FRBOizw+HYZX6nnSQ+aTMyXNuIXCv4Cp+1rSGdLwnRqbY5iUQca/8VZF45iZAgMB
# AAGjRjBEMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNV
# HQ4EFgQU1v0fOEkDehQn807IU73u51uJNQ0wDQYJKoZIhvcNAQEFBQADggEBABwb
# e2Ghq71GqGwx2/GoXa/Nv4XhW2O0TT5vgn6RysorCPUKTnCYKn6wGWZpdMbndXXU
# d6ziS+EW0+cxr7ZdFCTsfBroArJ3BIFjPoRt3hYqZR154nLNRnFPKhzgpusqDpSx
# BnMd7wRrKsW3GdSOfeGyiR7/9Ye2uiFp6y4wpU/qcU+LuxS2fbyUB2XGVPPWXxxF
# bjtgrlit7czi7WTjfe4YVgxyyrJ9IsMz8fPlLPy9Pfbfacpo6/p6qINhsmv+/V1o
# 7U2XIlg2w1ABj20sZ3mn+TKS2mmxNkIdCb38rUK8UJwqHX9byi9M1MrJYFJwRNwH
# 37l4hxzeVXIaiA6vWJAwggZqMIIFUqADAgECAhADAZoCOv9YsWvW1ermF/BmMA0G
# CSqGSIb3DQEBBQUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IEFzc3VyZWQgSUQgQ0EtMTAeFw0xNDEwMjIwMDAwMDBaFw0yNDEwMjIwMDAwMDBa
# MEcxCzAJBgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDElMCMGA1UEAxMcRGln
# aUNlcnQgVGltZXN0YW1wIFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKNkXfx8s+CCNeDg9sYq5kl1O8xu4FOpnx9kWeZ8a39rjJ1V+JLj
# ntVaY1sCSVDZg85vZu7dy4XpX6X51Id0iEQ7Gcnl9ZGfxhQ5rCTqqEsskYnMXij0
# ZLZQt/USs3OWCmejvmGfrvP9Enh1DqZbFP1FI46GRFV9GIYFjFWHeUhG98oOjafe
# Tl/iqLYtWQJhiGFyGGi5uHzu5uc0LzF3gTAfuzYBje8n4/ea8EwxZI3j6/oZh6h+
# z+yMDDZbesF6uHjHyQYuRhDIjegEYNu8c3T6Ttj+qkDxss5wRoPp2kChWTrZFQlX
# mVYwk/PJYczQCMxr7GJCkawCwO+k8IkRj3cCAwEAAaOCAzUwggMxMA4GA1UdDwEB
# /wQEAwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIIB
# vwYDVR0gBIIBtjCCAbIwggGhBglghkgBhv1sBwEwggGSMCgGCCsGAQUFBwIBFhxo
# dHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMIIBZAYIKwYBBQUHAgIwggFWHoIB
# UgBBAG4AeQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAgAEMAZQByAHQAaQBmAGkA
# YwBhAHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAgAGEAYwBjAGUAcAB0AGEA
# bgBjAGUAIABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBlAHIAdAAgAEMAUAAvAEMA
# UABTACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBuAGcAIABQAGEAcgB0AHkA
# IABBAGcAcgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAgAGwAaQBtAGkAdAAgAGwA
# aQBhAGIAaQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAgAGkAbgBjAG8AcgBwAG8A
# cgBhAHQAZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIAByAGUAZgBlAHIAZQBuAGMA
# ZQAuMAsGCWCGSAGG/WwDFTAfBgNVHSMEGDAWgBQVABIrE5iymQftHt+ivlcNK2cC
# zTAdBgNVHQ4EFgQUYVpNJLZJMp1KKnkag0v0HonByn0wfQYDVR0fBHYwdDA4oDag
# NIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEQ0Et
# MS5jcmwwOKA2oDSGMmh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFz
# c3VyZWRJRENBLTEuY3JsMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURDQS0xLmNydDANBgkqhkiG
# 9w0BAQUFAAOCAQEAnSV+GzNNsiaBXJuGziMgD4CH5Yj//7HUaiwx7ToXGXEXzakb
# vFoWOQCd42yE5FpA+94GAYw3+puxnSR+/iCkV61bt5qwYCbqaVchXTQvH3Gwg5QZ
# BWs1kBCge5fH9j/n4hFBpr1i2fAnPTgdKG86Ugnw7HBi02JLsOBzppLA044x2C/j
# bRcTBu7kA7YUq/OPQ6dxnSHdFMoVXZJB2vkPgdGZdA0mxA5/G7X1oPHGdwYoFenY
# k+VVFvC7Cqsc21xIJ2bIo4sKHOWV2q7ELlmgYd3a822iYemKC23sEhi991VUQAOS
# K2vCUcIKSK+w1G7g9BQKOhvjjz3Kr2qNe9zYRDCCBs0wggW1oAMCAQICEAb9+QOW
# A63qAArrPye7uhswDQYJKoZIhvcNAQEFBQAwZTELMAkGA1UEBhMCVVMxFTATBgNV
# BAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIG
# A1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4XDTA2MTExMDAwMDAw
# MFoXDTIxMTExMDAwMDAwMFowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lD
# ZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGln
# aUNlcnQgQXNzdXJlZCBJRCBDQS0xMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB
# CgKCAQEA6IItmfnKwkKVpYBzQHDSnlZUXKnE0kEGj8kz/E1FkVyBn+0snPgWWd+e
# tSQVwpi5tHdJ3InECtqvy15r7a2wcTHrzzpADEZNk+yLejYIA6sMNP4YSYL+x8cx
# SIB8HqIPkg5QycaH6zY/2DDD/6b3+6LNb3Mj/qxWBZDwMiEWicZwiPkFl32jx0Pd
# Aug7Pe2xQaPtP77blUjE7h6z8rwMK5nQxl0SQoHhg26Ccz8mSxSQrllmCsSNvtLO
# Bq6thG9IhJtPQLnxTPKvmPv2zkBdXPao8S+v7Iki8msYZbHBc63X8djPHgp0XEK4
# aH631XcKJ1Z8D2KkPzIUYJX9BwSiCQIDAQABo4IDejCCA3YwDgYDVR0PAQH/BAQD
# AgGGMDsGA1UdJQQ0MDIGCCsGAQUFBwMBBggrBgEFBQcDAgYIKwYBBQUHAwMGCCsG
# AQUFBwMEBggrBgEFBQcDCDCCAdIGA1UdIASCAckwggHFMIIBtAYKYIZIAYb9bAAB
# BDCCAaQwOgYIKwYBBQUHAgEWLmh0dHA6Ly93d3cuZGlnaWNlcnQuY29tL3NzbC1j
# cHMtcmVwb3NpdG9yeS5odG0wggFkBggrBgEFBQcCAjCCAVYeggFSAEEAbgB5ACAA
# dQBzAGUAIABvAGYAIAB0AGgAaQBzACAAQwBlAHIAdABpAGYAaQBjAGEAdABlACAA
# YwBvAG4AcwB0AGkAdAB1AHQAZQBzACAAYQBjAGMAZQBwAHQAYQBuAGMAZQAgAG8A
# ZgAgAHQAaABlACAARABpAGcAaQBDAGUAcgB0ACAAQwBQAC8AQwBQAFMAIABhAG4A
# ZAAgAHQAaABlACAAUgBlAGwAeQBpAG4AZwAgAFAAYQByAHQAeQAgAEEAZwByAGUA
# ZQBtAGUAbgB0ACAAdwBoAGkAYwBoACAAbABpAG0AaQB0ACAAbABpAGEAYgBpAGwA
# aQB0AHkAIABhAG4AZAAgAGEAcgBlACAAaQBuAGMAbwByAHAAbwByAGEAdABlAGQA
# IABoAGUAcgBlAGkAbgAgAGIAeQAgAHIAZQBmAGUAcgBlAG4AYwBlAC4wCwYJYIZI
# AYb9bAMVMBIGA1UdEwEB/wQIMAYBAf8CAQAweQYIKwYBBQUHAQEEbTBrMCQGCCsG
# AQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0
# dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RD
# QS5jcnQwgYEGA1UdHwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmw0
# LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwHQYDVR0O
# BBYEFBUAEisTmLKZB+0e36K+Vw0rZwLNMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1R
# i6enIZ3zbcgPMA0GCSqGSIb3DQEBBQUAA4IBAQBGUD7Jtygkpzgdtlspr1LPUukx
# R6tWXHvVDQtBs+/sdR90OPKyXGGinJXDUOSCuSPRujqGcq04eKx1XRcXNHJHhZRW
# 0eu7NoR3zCSl8wQZVann4+erYs37iy2QwsDStZS9Xk+xBdIOPRqpFFumhjFiqKgz
# 5Js5p8T1zh14dpQlc+Qqq8+cdkvtX8JLFuRLcEwAiR78xXm8TBJX/l/hHrwCXaj+
# +wc4Tw3GXZG5D2dFzdaD7eeSDY2xaYxP+1ngIw/Sqq4AfO6cQg7PkdcntxbuD8O9
# fAqg7iwIVYUiuOsYGk38KiGtSTGDR5V3cdyxG0tLHBCcdxTBnU8vWpUIKRAmMYID
# 4jCCA94CAQEwLjAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QCEF2h+NwZe+WY
# TAeJKV8mdqowCQYFKw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAw
# GQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisG
# AQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFHDH6+jx3ZcRkDrs3SpO35lcuDu4MA0G
# CSqGSIb3DQEBAQUABIIBAFYUdsPWoNM3Wzpx5WIu/tDfXzhQeToWFmJ4b4eQwqSS
# bC/zwQmxofKfSy1HwNCnkclPj0PvBjvUicHpXHhR7UjXbMFD5YjptjICcnwMWwPY
# m/HxOhsTzQX3i5D7ghqDJ+U2xTyLxYH7/Gdt8pFnCfbU9cZbaTWULHpTAjintFGW
# gNrzwdaw2f4MQc7LUsYGzzi6QkwXpsA+EF3ITJYzv4c1i2txO1ihfEG+5Xbh2DNP
# ceR6yvIgMDAlT30Okw3VRUzvOsQkzps04+Oio/eNDBxjBMqjHEVkCtyLYAIavZOO
# Q966mEs4gaiY7pbhdYC+mTWGfhTYnlzTeKaHTz7Qb/uhggIPMIICCwYJKoZIhvcN
# AQkGMYIB/DCCAfgCAQEwdjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNl
# cnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdp
# Q2VydCBBc3N1cmVkIElEIENBLTECEAMBmgI6/1ixa9bV6uYX8GYwCQYFKw4DAhoF
# AKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTIw
# MTEyOTIwNDMxN1owIwYJKoZIhvcNAQkEMRYEFL1STAYmYTznk8n7yKnhQFhtC96w
# MA0GCSqGSIb3DQEBAQUABIIBAB75tuNvVYPu9JK8zKvBdUR+EzE6pkn3BeNTBqyT
# 3+5ye1Jlo/3r9+vo6d1RB8FjtLS+otMILsuncqFLKeyEDPgGZBb/qOtZUf7B3jtB
# HGvhM9C8nqBrkC0QqKODRJwyfPPj+zYy5GbrbJXp6ydRmru8Xq1PCAZzp8kvsNmv
# AaNBlgUFx2giGHUFwirfqQDgjsUO1yfCg+rSWNtiU+39AQKGzxUrNF2C5ilrEXYp
# fGv0tIbenn1YG+pve6u2cvXQcpeiojkLPoESsgrMYYjgYN6IhaOfYzxsud+X1d/O
# C5C3dPCwp7Gcd+6jIf0IBdcQO6EZy4B+5IbKqqcumOKXhcs=
# SIG # End signature block
