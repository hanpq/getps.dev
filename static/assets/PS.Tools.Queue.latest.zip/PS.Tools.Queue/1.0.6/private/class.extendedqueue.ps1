﻿class ExtendedQueue {
    [System.Collections.Queue]$Queue
    [system.collections.Generic.Queue[pscustomobject]]$LastOperations
    [int64]$TotalItemsAdded
    [int64]$TotalItemsRemoved
    [double]$AddPerSec
    [double]$RemovePerSec
    [double]$Velocity
    [int]$PerformanceHistory
    
    [void]AddQueueItem (
        $Item
    ) {
        $this.Queue.Enqueue($item)
        $this.LastOperations.Enqueue(([pscustomobject]@{Type = 'Add'; TimeStamp = ([datetime]::Now) }))
        $this.TotalItemsAdded++
        $this.CalculateSpeed()
    }

    [psobject]GetNextQueueItem() {
        try {
            $ReturnObject = $this.Queue.Dequeue()
            $this.LastOperations.Enqueue(([pscustomobject]@{Type = 'Remove'; TimeStamp = ([datetime]::Now) }))
            $this.TotalItemsRemoved++
        } catch {
            $ReturnObject = $null
        }
        $this.CalculateSpeed()
        return $ReturnObject
    }

    [psobject]ShowNextQueueItem() {
        return $this.Queue.Peek()
    }

    [int64]GetQueueCount() {
        return $this.Queue.Count
    }

    [void]ClearAllQueueItems() {
        $this.Queue.Clear()
    }

    [array]GetAllQueueItems() {
        $Result = while ($this.GetQueueCount()) {
            $this.GetNextQueueItem()
            $this.TotalItemsRemoved++
        }
        $this.CalculateSpeed()
        return $Result
    }

    [void]RotateLastOperations ($CurrentTime) {
        while ($this.LastOperations.Count -ge $this.PerformanceHistory) {
            $null = $this.LastOperations.Dequeue()
        }
    }

    [void]CalculateSpeed () {
        $CurrentTime = [datetime]::Now
        $this.RotateLastOperations($CurrentTime)
        $ItemsAdded = $this.LastOperations.Where( { $PSItem.Type -eq 'Add' }).Count
        $ItemsRemoved = $this.LastOperations.Where( { $PSItem.Type -eq 'Remove' }).Count
            
        try {
            $this.AddPerSec = $ItemsAdded / ($CurrentTime - $this.LastOperations.Where( { $PSItem.Type -eq 'Add' })[0].TimeStamp).TotalSeconds
        } catch {
            $this.AddPerSec = 0
        }
            
        try {
            $this.RemovePerSec = $ItemsRemoved / ($CurrentTime - $this.LastOperations.Where( { $PSItem.Type -eq 'Remove' })[0].TimeStamp).TotalSeconds
        } catch {
            $this.RemovePerSec = 0
        }
            
        $this.Velocity = $this.AddPerSec - $this.RemovePerSec
    }

    ExtendedQueue () {
        $this.Queue = [System.Collections.Queue]::New()
        $this.LastOperations = [system.collections.Generic.Queue[pscustomobject]]::New()
        $this.TotalItemsAdded = 0
        $this.TotalItemsRemoved = 0
        $this.AddPerSec = 0
        $this.RemovePerSec = 0
        $this.PerformanceHistory = 50
    }
}

# SIG # Begin signature block
# MIIRyAYJKoZIhvcNAQcCoIIRuTCCEbUCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUcNYpbKmWffy5iIxBuSx90JjB
# dDyggg0/MIIDBDCCAeygAwIBAgIQXaH43Bl75ZhMB4kpXyZ2qjANBgkqhkiG9w0B
# AQUFADAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QwHhcNMjAxMDIyMDczMDU3
# WhcNMjUxMDIyMDc0MDU3WjAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QwggEi
# MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQClDvznsRz3hBOHS8rZ5ZlNB/ac
# GrKUQyoH0Pk6JONmIBeQPLwurne3ulSwb+6cbwwgp87eSnGoq4YbAFfqTbwytKLn
# YmIoHGiCrwxZb5YU6ijOrW6Sywa+H+/uKsZqJfXFRn1vGnC5tZwa5rSngLaow1qV
# tvyRQGRGNpI02hUwtChneJJmwk2B8dtY1ECH6Ob9LFlWETcETy5T5RKSS1sRWATk
# K9EQsZ65AHbGKGkpDv8y/+g7hg3KKU+m8f3ahMscMB5tvyPr3tmPsMFpFW3kCfz0
# FRBOizw+HYZX6nnSQ+aTMyXNuIXCv4Cp+1rSGdLwnRqbY5iUQca/8VZF45iZAgMB
# AAGjRjBEMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNV
# HQ4EFgQU1v0fOEkDehQn807IU73u51uJNQ0wDQYJKoZIhvcNAQEFBQADggEBABwb
# e2Ghq71GqGwx2/GoXa/Nv4XhW2O0TT5vgn6RysorCPUKTnCYKn6wGWZpdMbndXXU
# d6ziS+EW0+cxr7ZdFCTsfBroArJ3BIFjPoRt3hYqZR154nLNRnFPKhzgpusqDpSx
# BnMd7wRrKsW3GdSOfeGyiR7/9Ye2uiFp6y4wpU/qcU+LuxS2fbyUB2XGVPPWXxxF
# bjtgrlit7czi7WTjfe4YVgxyyrJ9IsMz8fPlLPy9Pfbfacpo6/p6qINhsmv+/V1o
# 7U2XIlg2w1ABj20sZ3mn+TKS2mmxNkIdCb38rUK8UJwqHX9byi9M1MrJYFJwRNwH
# 37l4hxzeVXIaiA6vWJAwggT+MIID5qADAgECAhANQkrgvjqI/2BAIc4UAPDdMA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0EwHhcNMjEwMTAxMDAwMDAw
# WhcNMzEwMTA2MDAwMDAwWjBIMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNl
# cnQsIEluYy4xIDAeBgNVBAMTF0RpZ2lDZXJ0IFRpbWVzdGFtcCAyMDIxMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwuZhhGfFivUNCKRFymNrUdc6EUK9
# CnV1TZS0DFC1JhD+HchvkWsMlucaXEjvROW/m2HNFZFiWrj/ZwucY/02aoH6Kfjd
# K3CF3gIY83htvH35x20JPb5qdofpir34hF0edsnkxnZ2OlPR0dNaNo/Go+EvGzq3
# YdZz7E5tM4p8XUUtS7FQ5kE6N1aG3JMjjfdQJehk5t3Tjy9XtYcg6w6OLNUj2vRN
# eEbjA4MxKUpcDDGKSoyIxfcwWvkUrxVfbENJCf0mI1P2jWPoGqtbsR0wwptpgrTb
# /FZUvB+hh6u+elsKIC9LCcmVp42y+tZji06lchzun3oBc/gZ1v4NSYS9AQIDAQAB
# o4IBuDCCAbQwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/
# BAwwCgYIKwYBBQUHAwgwQQYDVR0gBDowODA2BglghkgBhv1sBwEwKTAnBggrBgEF
# BQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMB8GA1UdIwQYMBaAFPS2
# 4SAd/imu0uRhpbKiJbLIFzVuMB0GA1UdDgQWBBQ2RIaOpLqwZr68KC0dRDbd42p6
# vDBxBgNVHR8EajBoMDKgMKAuhixodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hh
# Mi1hc3N1cmVkLXRzLmNybDAyoDCgLoYsaHR0cDovL2NybDQuZGlnaWNlcnQuY29t
# L3NoYTItYXNzdXJlZC10cy5jcmwwgYUGCCsGAQUFBwEBBHkwdzAkBggrBgEFBQcw
# AYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tME8GCCsGAQUFBzAChkNodHRwOi8v
# Y2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEVGltZXN0
# YW1waW5nQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQBIHNy16ZojvOca5yAOjmdG
# /UJyUXQKI0ejq5LSJcRwWb4UoOUngaVNFBUZB3nw0QTDhtk7vf5EAmZN7WmkD/a4
# cM9i6PVRSnh5Nnont/PnUp+Tp+1DnnvntN1BIon7h6JGA0789P63ZHdjXyNSaYOC
# +hpT7ZDMjaEXcw3082U5cEvznNZ6e9oMvD0y0BvL9WH8dQgAdryBDvjA4VzPxBFy
# 5xtkSdgimnUVQvUtMjiB2vRgorq0Uvtc4GEkJU+y38kpqHNDUdq9Y9YfW5v3LhtP
# Ex33Sg1xfpe39D+E68Hjo0mh+s6nv1bPull2YYlffqe0jmd4+TaY4cso2luHpoov
# MIIFMTCCBBmgAwIBAgIQCqEl1tYyG35B5AXaNpfCFTANBgkqhkiG9w0BAQsFADBl
# MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3
# d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJv
# b3QgQ0EwHhcNMTYwMTA3MTIwMDAwWhcNMzEwMTA3MTIwMDAwWjByMQswCQYDVQQG
# EwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNl
# cnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgVGltZXN0
# YW1waW5nIENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvdAy7kvN
# j3/dqbqCmcU5VChXtiNKxA4HRTNREH3Q+X1NaH7ntqD0jbOI5Je/YyGQmL8TvFfT
# w+F+CNZqFAA49y4eO+7MpvYyWf5fZT/gm+vjRkcGGlV+Cyd+wKL1oODeIj8O/36V
# +/OjuiI+GKwR5PCZA207hXwJ0+5dyJoLVOOoCXFr4M8iEA91z3FyTgqt30A6XLdR
# 4aF5FMZNJCMwXbzsPGBqrC8HzP3w6kfZiFBe/WZuVmEnKYmEUeaC50ZQ/ZQqLKfk
# dT66mA+Ef58xFNat1fJky3seBdCEGXIX8RcG7z3N1k3vBkL9olMqT4UdxB08r8/a
# rBD13ays6Vb/kwIDAQABo4IBzjCCAcowHQYDVR0OBBYEFPS24SAd/imu0uRhpbKi
# JbLIFzVuMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3zbcgPMBIGA1UdEwEB
# /wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMI
# MHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MIGBBgNVHR8EejB4MDqgOKA2hjRo
# dHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0Eu
# Y3JsMDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1
# cmVkSURSb290Q0EuY3JsMFAGA1UdIARJMEcwOAYKYIZIAYb9bAACBDAqMCgGCCsG
# AQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMAsGCWCGSAGG/WwH
# ATANBgkqhkiG9w0BAQsFAAOCAQEAcZUS6VGHVmnN793afKpjerN4zwY3QITvS4S/
# ys8DAv3Fp8MOIEIsr3fzKx8MIVoqtwU0HWqumfgnoma/Capg33akOpMP+LLR2HwZ
# YuhegiUexLoceywh4tZbLBQ1QwRostt1AuByx5jWPGTlH0gQGF+JOGFNYkYkh2OM
# kVIsrymJ5Xgf1gsUpYDXEkdws3XVk4WTfraSZ/tTYYmo9WuWwPRYaQ18yAGxuSh1
# t5ljhSKMYcp5lH5Z/IwP42+1ASa2bKXuh1Eh5Fhgm7oMLSttosR+u8QlK0cCCHxJ
# rhO24XxCQijGGFbPQTS2Zl22dHv1VjMiLyI2skuiSpXY9aaOUjGCA/MwggPvAgEB
# MC4wGjEYMBYGA1UEAwwPSGFubmVzUGFsbXF1aXN0AhBdofjcGXvlmEwHiSlfJnaq
# MAkGBSsOAwIaBQCgeDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MCMGCSqGSIb3DQEJBDEWBBQf47un6pWLq0glyHi3VSbfhgkL3jANBgkqhkiG9w0B
# AQEFAASCAQCFVQzf63VrrxYoAHr7I1T++ZbTBOipl6nwr9IWGIylraGxjQU3UZdl
# +y83XzYZEN55UM5Jyxoq5xzFPAvzQy32H78htrGPB8WP4VuoDKvSosYL5GT0L2Pq
# Hwe7BlKHUeuXLVRWXo8t3eNmtXz82JsQ29Fvck40y7rztkVd5A0HobGZUUiPeUx3
# 5mKNi+ad8j+upOzM10FN32qh3Xz84q0oGe1vKzFJH8NDtbc710G6E/l6hZ8QP6lr
# 6vvcSjFIr44wt6ACOPfUYSMecHGIWuTJBR1CM41ycACaF4sbhupd0MvspjB7lN3t
# ZV3uAFrALRAErK23JaeZrC6BuJoMQm8WoYICIDCCAhwGCSqGSIb3DQEJBjGCAg0w
# ggIJAgEBMIGGMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNI
# QTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0ECEA1CSuC+Ooj/YEAhzhQA8N0w
# CQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcN
# AQkFMQ8XDTIxMDEyMjIxMDEwNVowIwYJKoZIhvcNAQkEMRYEFEAk/EkHKy1ab0gU
# SGLdyTn1C9xWMA0GCSqGSIb3DQEBAQUABIIBAAEBmxuRgruHP8p4Gnv/3SBRfRkP
# p5YJ0iefdzxAXHQf4oZn5psx6cd0b7HexbKu02yYJd9KHfZFRYUv47lNyCRlOvPC
# /zn0w7BGzrPE4C7aS9Qydvcxk3kcZnN/sobVjasI3TEj5KIyMyB09P5f+0jnTQ/G
# Ruj31eJkrjG3t5VbCtsEasNF2Z67MASVeZoAZwF9JlLMSY+zVbvchbhm71WfE6GS
# KwW4ZwQV2OijzkgckV2FVq9PDrnSziO1sme+7ddA0SvST1f+puUnr+oaq+CF8SbA
# 0HCrhrdQZ/Ue7t4HdZ8YUrAd3qqaYxKu0z+EW3Q9f24wK/VHWTvhj3xSWOY=
# SIG # End signature block
