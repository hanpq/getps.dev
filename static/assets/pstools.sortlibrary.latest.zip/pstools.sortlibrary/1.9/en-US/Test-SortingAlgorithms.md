---
external help file: pstools.sortlibrary-help.xml
Module Name: pstools.sortlibrary
online version:
schema: 2.0.0
---

# Test-SortingAlgorithms

## SYNOPSIS

## SYNTAX

```
Test-SortingAlgorithms [<CommonParameters>]
```

## DESCRIPTION
Runs all sorting functions

## EXAMPLES

### EXAMPLE 1
```
Test-SortingAlgorithms
Description of example
```

## PARAMETERS

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
