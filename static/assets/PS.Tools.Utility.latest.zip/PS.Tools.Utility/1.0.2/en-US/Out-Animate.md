---
external help file: PS.Tools.Utility-help.xml
Module Name: PS.Tools.Utility
online version:
schema: 2.0.0
---

# Out-Animate

## SYNOPSIS

## SYNTAX

```
Out-Animate [-InputObject] <String> [[-ForegroundColor] <ConsoleColor>] [[-AnimationSpeed] <Int32>]
 [<CommonParameters>]
```

## DESCRIPTION
Visuallt output a string to the console.
The text is progressivly written to the console.

## EXAMPLES

### EXAMPLE 1
```
Description of example
'Hello World!' | Out-Animate -AnimationSpeed 50 -ForegroundColor 'Cyan'
```

## PARAMETERS

### -InputObject
{{ Fill InputObject Description }}

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 1
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -ForegroundColor
Defines the color of the text to be written.

```yaml
Type: ConsoleColor
Parameter Sets: (All)
Aliases:
Accepted values: Black, DarkBlue, DarkGreen, DarkCyan, DarkRed, DarkMagenta, DarkYellow, Gray, DarkGray, Blue, Green, Cyan, Red, Magenta, Yellow, White

Required: False
Position: 2
Default value: White
Accept pipeline input: False
Accept wildcard characters: False
```

### -AnimationSpeed
Defines the speed at which the text is written to the console.

```yaml
Type: Int32
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: 30
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
