﻿# Load module helper functions
.(Join-Path -Path $PSScriptRoot -ChildPath '\include\ModuleHelperFunctions.ps1')

Initialize-ModuleConfiguration
Initialize-PSLogSettings
Import-Module Microsoft.PowerShell.Security -Force -ErrorAction Stop

# Import public and private functions files
Get-ChildItem -Path (Get-ModuleConfiguration).ModuleRootPath -Directory | Where-Object { $_.name -eq 'public' -or $_.name -eq 'private' } | ForEach-Object {
    Get-ChildItem -Path $_.FullName -Include '*.ps1' -Recurse -Exclude '*.Tests.*' | ForEach-Object {
        . $_.FullName
    }
}

# Evaluate compatible powershell editions
$Continue = $true
$ManifestContent = (Get-ModuleConfiguration).ModuleManifest
if ($ManifestContent.ContainsKey('CompatiblePSEditions')) {
    if (-not ($ManifestContent.CompatiblePSEditions.Contains($PSVersionTable.PSEdition))) {
        throw ('This module does not support the current PSEdition: [{0}]' -f $PSVersionTable.PSEdition)
        $Continue = $false
    }
}

if ($Continue) {
    # Test script hash
    $ModuleRootPath = (Get-ModuleConfiguration).ModuleRootPath
    $IncludeDirectory = (Get-ModuleConfiguration).ModuleFolders.Include
    $AllScriptFilesCases = Get-ChildItem -Path $ModuleRootPath -Include "*.ps1", "*.psm1", "*.psd1" -Recurse | Where-Object { $_.fullname -notlike ('{0}\*' -f $IncludeDirectory) }
    $Passing = $true
    $AllScriptFilesCases | foreach-object {
        $AuthResult = Get-AuthenticodeSignature -FilePath $PSItem.FullName | Select-Object -ExpandProperty Status
        if ($AuthResult -eq 'HashMismatch') {
            $Passing = $false
            Write-CheckListItem -Message ('Hash validation failed: {0}' -f $PSItem.Name)
        }
    }
    if ($Passing -eq $false) {
        break
    }
}

# SIG # Begin signature block
# MIIRyAYJKoZIhvcNAQcCoIIRuTCCEbUCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUFxbYO8t/uhwa7e45eAXprNoy
# HYSggg0/MIIDBDCCAeygAwIBAgIQXaH43Bl75ZhMB4kpXyZ2qjANBgkqhkiG9w0B
# AQUFADAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QwHhcNMjAxMDIyMDczMDU3
# WhcNMjUxMDIyMDc0MDU3WjAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QwggEi
# MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQClDvznsRz3hBOHS8rZ5ZlNB/ac
# GrKUQyoH0Pk6JONmIBeQPLwurne3ulSwb+6cbwwgp87eSnGoq4YbAFfqTbwytKLn
# YmIoHGiCrwxZb5YU6ijOrW6Sywa+H+/uKsZqJfXFRn1vGnC5tZwa5rSngLaow1qV
# tvyRQGRGNpI02hUwtChneJJmwk2B8dtY1ECH6Ob9LFlWETcETy5T5RKSS1sRWATk
# K9EQsZ65AHbGKGkpDv8y/+g7hg3KKU+m8f3ahMscMB5tvyPr3tmPsMFpFW3kCfz0
# FRBOizw+HYZX6nnSQ+aTMyXNuIXCv4Cp+1rSGdLwnRqbY5iUQca/8VZF45iZAgMB
# AAGjRjBEMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNV
# HQ4EFgQU1v0fOEkDehQn807IU73u51uJNQ0wDQYJKoZIhvcNAQEFBQADggEBABwb
# e2Ghq71GqGwx2/GoXa/Nv4XhW2O0TT5vgn6RysorCPUKTnCYKn6wGWZpdMbndXXU
# d6ziS+EW0+cxr7ZdFCTsfBroArJ3BIFjPoRt3hYqZR154nLNRnFPKhzgpusqDpSx
# BnMd7wRrKsW3GdSOfeGyiR7/9Ye2uiFp6y4wpU/qcU+LuxS2fbyUB2XGVPPWXxxF
# bjtgrlit7czi7WTjfe4YVgxyyrJ9IsMz8fPlLPy9Pfbfacpo6/p6qINhsmv+/V1o
# 7U2XIlg2w1ABj20sZ3mn+TKS2mmxNkIdCb38rUK8UJwqHX9byi9M1MrJYFJwRNwH
# 37l4hxzeVXIaiA6vWJAwggT+MIID5qADAgECAhANQkrgvjqI/2BAIc4UAPDdMA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0EwHhcNMjEwMTAxMDAwMDAw
# WhcNMzEwMTA2MDAwMDAwWjBIMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNl
# cnQsIEluYy4xIDAeBgNVBAMTF0RpZ2lDZXJ0IFRpbWVzdGFtcCAyMDIxMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwuZhhGfFivUNCKRFymNrUdc6EUK9
# CnV1TZS0DFC1JhD+HchvkWsMlucaXEjvROW/m2HNFZFiWrj/ZwucY/02aoH6Kfjd
# K3CF3gIY83htvH35x20JPb5qdofpir34hF0edsnkxnZ2OlPR0dNaNo/Go+EvGzq3
# YdZz7E5tM4p8XUUtS7FQ5kE6N1aG3JMjjfdQJehk5t3Tjy9XtYcg6w6OLNUj2vRN
# eEbjA4MxKUpcDDGKSoyIxfcwWvkUrxVfbENJCf0mI1P2jWPoGqtbsR0wwptpgrTb
# /FZUvB+hh6u+elsKIC9LCcmVp42y+tZji06lchzun3oBc/gZ1v4NSYS9AQIDAQAB
# o4IBuDCCAbQwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/
# BAwwCgYIKwYBBQUHAwgwQQYDVR0gBDowODA2BglghkgBhv1sBwEwKTAnBggrBgEF
# BQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMB8GA1UdIwQYMBaAFPS2
# 4SAd/imu0uRhpbKiJbLIFzVuMB0GA1UdDgQWBBQ2RIaOpLqwZr68KC0dRDbd42p6
# vDBxBgNVHR8EajBoMDKgMKAuhixodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hh
# Mi1hc3N1cmVkLXRzLmNybDAyoDCgLoYsaHR0cDovL2NybDQuZGlnaWNlcnQuY29t
# L3NoYTItYXNzdXJlZC10cy5jcmwwgYUGCCsGAQUFBwEBBHkwdzAkBggrBgEFBQcw
# AYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tME8GCCsGAQUFBzAChkNodHRwOi8v
# Y2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEVGltZXN0
# YW1waW5nQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQBIHNy16ZojvOca5yAOjmdG
# /UJyUXQKI0ejq5LSJcRwWb4UoOUngaVNFBUZB3nw0QTDhtk7vf5EAmZN7WmkD/a4
# cM9i6PVRSnh5Nnont/PnUp+Tp+1DnnvntN1BIon7h6JGA0789P63ZHdjXyNSaYOC
# +hpT7ZDMjaEXcw3082U5cEvznNZ6e9oMvD0y0BvL9WH8dQgAdryBDvjA4VzPxBFy
# 5xtkSdgimnUVQvUtMjiB2vRgorq0Uvtc4GEkJU+y38kpqHNDUdq9Y9YfW5v3LhtP
# Ex33Sg1xfpe39D+E68Hjo0mh+s6nv1bPull2YYlffqe0jmd4+TaY4cso2luHpoov
# MIIFMTCCBBmgAwIBAgIQCqEl1tYyG35B5AXaNpfCFTANBgkqhkiG9w0BAQsFADBl
# MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3
# d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJv
# b3QgQ0EwHhcNMTYwMTA3MTIwMDAwWhcNMzEwMTA3MTIwMDAwWjByMQswCQYDVQQG
# EwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNl
# cnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgVGltZXN0
# YW1waW5nIENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvdAy7kvN
# j3/dqbqCmcU5VChXtiNKxA4HRTNREH3Q+X1NaH7ntqD0jbOI5Je/YyGQmL8TvFfT
# w+F+CNZqFAA49y4eO+7MpvYyWf5fZT/gm+vjRkcGGlV+Cyd+wKL1oODeIj8O/36V
# +/OjuiI+GKwR5PCZA207hXwJ0+5dyJoLVOOoCXFr4M8iEA91z3FyTgqt30A6XLdR
# 4aF5FMZNJCMwXbzsPGBqrC8HzP3w6kfZiFBe/WZuVmEnKYmEUeaC50ZQ/ZQqLKfk
# dT66mA+Ef58xFNat1fJky3seBdCEGXIX8RcG7z3N1k3vBkL9olMqT4UdxB08r8/a
# rBD13ays6Vb/kwIDAQABo4IBzjCCAcowHQYDVR0OBBYEFPS24SAd/imu0uRhpbKi
# JbLIFzVuMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3zbcgPMBIGA1UdEwEB
# /wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMI
# MHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MIGBBgNVHR8EejB4MDqgOKA2hjRo
# dHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0Eu
# Y3JsMDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1
# cmVkSURSb290Q0EuY3JsMFAGA1UdIARJMEcwOAYKYIZIAYb9bAACBDAqMCgGCCsG
# AQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMAsGCWCGSAGG/WwH
# ATANBgkqhkiG9w0BAQsFAAOCAQEAcZUS6VGHVmnN793afKpjerN4zwY3QITvS4S/
# ys8DAv3Fp8MOIEIsr3fzKx8MIVoqtwU0HWqumfgnoma/Capg33akOpMP+LLR2HwZ
# YuhegiUexLoceywh4tZbLBQ1QwRostt1AuByx5jWPGTlH0gQGF+JOGFNYkYkh2OM
# kVIsrymJ5Xgf1gsUpYDXEkdws3XVk4WTfraSZ/tTYYmo9WuWwPRYaQ18yAGxuSh1
# t5ljhSKMYcp5lH5Z/IwP42+1ASa2bKXuh1Eh5Fhgm7oMLSttosR+u8QlK0cCCHxJ
# rhO24XxCQijGGFbPQTS2Zl22dHv1VjMiLyI2skuiSpXY9aaOUjGCA/MwggPvAgEB
# MC4wGjEYMBYGA1UEAwwPSGFubmVzUGFsbXF1aXN0AhBdofjcGXvlmEwHiSlfJnaq
# MAkGBSsOAwIaBQCgeDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MCMGCSqGSIb3DQEJBDEWBBTeJbXUZtgg8oaI4xNSb33mrg+HKjANBgkqhkiG9w0B
# AQEFAASCAQA00g87uyvlC6ngIjRr7wZy7xgHZXYIYdWOkRwVDoSnfKr7+NiO41El
# uDRH4WoDQihjcKYHOlPTngkcqeZqIZYFyU3kZIamjelMvLv0gfUwiPYOhSYaCLQL
# VoC/ec0128VVquPmt6S6m6z8DRI2nt5YeNj04jl6jrnbhJz5Jq44zi9M6E2JNarn
# JWYbXqkms9NA1kmy3Vn5gj/rYOMtgJ0vpredSnftG1Zw98Io7yIJynxO59OvkmF3
# c3Drf9yZcgUbUHU1HKD0n/oZ6veiYrgUYYYmr7SIV/TSxpvhl9bPSECSB/ee+JX4
# svz9lWIDyP2//UJCi+RCKBew99Nmc9RaoYICIDCCAhwGCSqGSIb3DQEJBjGCAg0w
# ggIJAgEBMIGGMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNI
# QTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0ECEA1CSuC+Ooj/YEAhzhQA8N0w
# CQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcN
# AQkFMQ8XDTIxMDExMDE5NDg0MFowIwYJKoZIhvcNAQkEMRYEFHSDhsdRPsCintAj
# DVuLBm94p7TiMA0GCSqGSIb3DQEBAQUABIIBAF5AszNXYDGQYLVWjcjDDFReGsZG
# IDPxSj8XCzUX7pfHfx0gOw5Nq7fyr1s3Sb/UGGJUf3AeVgHhEHPVTyl16c9+II1K
# U9GKukxCZF0/12UwskYNh8CLC5nVE5Lagg+huz3djWQhe2hMEspJw8NKMpIit5nT
# qHJFQd4bJ2L46aVwYu1l2qOaiR08dFolgW+8kHP36+bXgAHlM8yCrsU5B+N4QIXz
# wUNkkb7Dzxf+dMhxhgSzfQVrGeaxNK2urbhpi3YArCewRjgVKMssW+bOrMqPy6FH
# w3tCvnd/N3bkXZ8v8PxuVOyL5dexNWzj77l78bNCaEZ/H3QbAcbxAZj1OJc=
# SIG # End signature block
